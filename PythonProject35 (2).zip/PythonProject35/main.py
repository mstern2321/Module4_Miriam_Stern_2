from food import Food
from turtle import Screen
from snake import  Snake
from scoreboard import Scoreboard
from game_controller import GameController
# main.py sets up screen, snake, food, scoreboard and calls the game controller
screen = Screen()
screen.setup(width=700, height= 600)
screen.bgcolor("Black")
screen.title("Snake Game")
screen.tracer(0)

snake = Snake()
food = Food()
scoreboard = Scoreboard()
is_game_on = True
gc = GameController(screen, snake, food, is_game_on, scoreboard)
gc.setup_bindings()
gc.run_game_loop()
screen.exitonclick()