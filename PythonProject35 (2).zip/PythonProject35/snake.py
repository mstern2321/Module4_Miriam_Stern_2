import random
from turtle import Turtle


snake_palette = [ '#ff00ff', '#ff1aff', '#ff33ff', '#ff4dff', '#ff66ff', '#ff80ff', # High-energy Magentas
    '#ff00cc', '#ff0099', '#ff0066', '#ff1493', # Deep Pinks & DeepPink

    # --- COTTON CANDY & BUBBLEGUM PINKS ---
    '#ff66b2', '#ff80bf', '#ff99cc', '#ffb3d9', '#ffcce6', '#ffe6f2', # Soft & Sugary

    # --- PEACHY PINKS & CORALS ---
    '#ff4d4d', '#ff6666', '#ff8080', '#ff9999', # Warm "Strawberry" tones
    '#ff7f50', '#ff8c69', '#ffa07a', '#ffb3a1', # Coral & Salmon

    # --- BRIGHT PEACH & SUNSET ORANGE ---
    '#ffcc99', '#ffd9b3', '#ffe6cc', '#fff2e6', # Creamy Oranges

    # --- ELECTRIC & LEMON YELLOWS ---
    '#ffff00', '#ffff33', '#ffff66', '#ffff99', # Neon Yellows
    '#fffacd', '#fff5b3', '#fff099', '#ffeb80', # Lemon Chiffon tones

    # --- MINT & SOFT AQUAS ---
    '#e0ffff', '#b2ffff', '#80ffff', '#4dffff', # Icy Cyans
    '#98fb98', '#afffaf', '#c6ffc6', '#ddffdd', # Sweet Mints

    # --- PERIWINKLE & LAVENDER ---
    '#e6e6ff', '#ccccff', '#b2b2ff', '#9999ff', # Soft Purples
    '#d8b2ff', '#cc99ff', '#bf80ff', '#b266ff', # Sugary Lilac

    # --- VIVID VIOLETS & ORCHIDS ---
    '#a64dff', '#9933ff', '#8c1aff', '#8000ff', # Intense Purple pop
    '#da70d6', '#ee82ee', '#ff82ff', '#ffb3ff'  # Orchids & Bright Violet
]
class Snake:

    def __init__(self) -> None:
        super().__init__()
        self.segments = []
        self.create_starting_snake()
        self.head = self.segments[0] # head is first segment in list of segments


    def create_starting_snake(self):
        """
        creates 3 segments in a row as the starting snake
        """
        starting_positions = [(0, 0), (-20, 0), (-40, 0)] # spaces the segments exactly 20 apart from each other

        for position in starting_positions:
            segment = Turtle()
            segment.shape("square")
            segment.shapesize(stretch_wid=1, stretch_len=3)
            segment.color(random.choice(snake_palette))
            segment.penup()
            segment.goto(position)
            self.segments.append(segment)




    def move(self):
        """
        moves the snake forward by making each segment follow the one ahead of it
        """
        for segment_index in range(len(self.segments)-1, 0, -1): # Looping through the segment list backwards until the head
            new_x = self.segments[segment_index - 1].xcor() # the new_x becomes the x position of the segment before it
            new_y = self.segments[segment_index - 1].ycor() # The new_y becomes the y position of the segment before it
            self.segments[segment_index].goto(new_x, new_y) # The segment goes to the x, y position of the segment before it

        self.head.forward(20) # Head moves forward 20




    def grow(self):
        """
        grows the snake by adding another segment
        """
        tail = self.segments[-1] # tail is the last segment in the list
        segment = Turtle()
        segment.shape("square")
        segment.shapesize(stretch_wid=1, stretch_len=3)
        segment.color(random.choice(snake_palette))
        segment.penup()
        segment.goto(tail.position())   # goes to the end of the snake
        self.segments.append(segment)

    def reset(self):
        """
        resets the snake to its starting state
        """
        for segment in self.segments:
            segment.hideturtle() # hide each segment of turtle
        self.segments.clear()
        self.create_starting_snake()
        self.head = self.segments[0]


    def up(self):
        """
        sets snake upwards
        """
        if self.head.heading() != 270: # if snake is not heading down (cannot reverse)
            self.head.setheading(90) # set it to go up


    def down(self):
        """
        sets snake downwards
        """
        if self.head.heading() != 90: # if snake is not heading up (cannot reverse)
            self.head.setheading(270) # set it to go down

    def left(self):
        """
        sets snake left
        """
        if self.head.heading() != 0: # if snake is not heading right (cannot reverse)
            self.head.setheading(180) # set it to go left

    def right(self):
        """
        sets snake right
        """
        if self.head.heading() != 180: # if snake is not heading left (cannot reverse)
            self.head.setheading(0) # set it to go right

