from turtle import Turtle
class Scoreboard(Turtle):
    """
    Manages the score display
    """
    def __init__(self, score : int=0) -> None:
        """
        creates the scoreboard
        """
        super().__init__()
        self.penup()
        self.hideturtle()
        self.color("white")
        self.score = score
        self.goto(0, 260)
        self.update_scoreboard()


    def update_scoreboard(self):
        """
        Updates the visible score
        """
        self.clear()
        self.write(
            f"Player score: {self.score}",
            align="center",
            font=("Arial", 16, "bold")
        )

    def increase_score(self):
        """
        increments player score by 1 and calls update scoreboard
        """
        self.score += 1
        self.update_scoreboard()
    def reset(self):
        """
        resets scoreboard
        """
        self.score = 0 # sets score back to 0
        self.update_scoreboard()
    def game_over(self):
        """
        Displays game over and player's score
        """
        self.clear()
        self.goto(0, 0)
        self.write(
            "GAME OVER",
            align="center",
            font=("Arial", 50, "bold")
        )
        self.goto(0, -70)
        self.write(
            f"Your score is: {self.score}",
            align="center",
            font=("Arial", 20, "bold")
        )

